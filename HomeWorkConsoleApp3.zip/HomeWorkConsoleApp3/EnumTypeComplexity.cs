﻿namespace HomeWorkConsoleApp3
{
    public enum EnumTypeComplexity
    {
        Лёгкая, Средняя, Сложная, Адская
    }
}
