﻿namespace HomeWorkConsoleApp3
{
    public enum EnumSelectTypeEnumerator
    {
        Complexity, Work
    }
}
