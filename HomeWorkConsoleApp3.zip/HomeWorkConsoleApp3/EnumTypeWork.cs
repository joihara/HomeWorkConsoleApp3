﻿namespace HomeWorkConsoleApp3
{
    public enum EnumTypeWork
    {
        Работа1, Работа2, Работа3
    }
}
